package com.example.bibliotecaalejandra;

public class RegisterResponse {
    private int code;
    private String message;

    public int getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }
}
